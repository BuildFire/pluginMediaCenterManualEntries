class Categories {
    constructor(data = {}) {
        // this.userId = data.userId || '';
        this.db = data.db;
    }

    getCategories(data, cb) {
        if (data && data.options) {
            this.db.find(data.options).then(function success(result) {
                if (!result.length) {
                    return cb(null, []);
                }

                if (result && result.length) {
                    return cb(null, result);
                }
            }, function fail() {
                return cb("Getting categories failed");
            });
        }
        else {
            return cb("No options provided");
        }
    };

    addCategory(data, cb) {
        if (data && data.name) {
            this.db.insert(new Category({
                name: data.name,
                icon: data.icon || '',
                sortBy: data.sortBy || Orders.ordersMap.Default,
                createdOn: new Date(),
                createdBy: data.createdBy || '',
                lastUpdatedOn: new Date(),
                lastUpdatedBy: data.lastUpdatedBy || '',
                deletedOn: '',
                deletedBy: ''
            })).then(function success(result) {
                return cb(null, result);
            }, function fail() {
                return cb("Adding category failed");
            });
        }
        else {
            return cb("No options provided");
        }
    };

    deleteCategory(categoryId, cb) {
        if (categoryId) {
            this.db.delete(categoryId).then(function (data) {
                return cb(null, data);
            }, function (err) {
                console.log(err);
                return cb("Error while deleting category");
            });
        }
        else {
            return cb("No id provided");
        }
    };

    updateCategory(data, cb) {
        if (data && data.id) {
            this.db.update(data.id, {
                name: data.name,
                icon: data.icon || '',
                sortBy: data.sortBy || Orders.ordersMap.Default,
                lastUpdatedOn: new Date(),
                lastUpdatedBy: data.lastUpdatedBy || '',
                deletedOn: '',
                deletedBy: ''
            }).then(function success(result) {
                return cb(null, result);
            }, function fail() {
                return cb("Updating category failed");
            });
        }
        else {
            return cb("No id provided");
        }
    }
}