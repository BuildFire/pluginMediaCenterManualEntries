class Category {
    constructor(data = {}) {
        this.id = data.id || '';
        this.icon = data.icon || '';
        this.name = data.name || '';
        this.subcategories = data.subcategories || [];
        this.sortBy = data.sortBy || Orders.ordersMap.Default;
        this.createdOn = data.createdOn || new Date();
        this.createdBy = data.createdBy || '';
        this.lastUpdatedOn = data.lastUpdatedOn || new Date();
        this.lastUpdatedBy = data.lastUpdatedBy || '';
        this.deletedOn = data.deletedOn || '';
        this.deletedBy = data.deletedBy || '';
    }
}